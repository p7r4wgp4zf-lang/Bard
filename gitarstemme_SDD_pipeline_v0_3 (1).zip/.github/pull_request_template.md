## Funksjon / brukerhistorier
- Story-ID(er):
- Spesifikasjon (lenke i repo):

## Endringer

## Risiko- og sikkerhetsvurdering
- Nye avhengigheter? Begrunnelse og review:
- Nye rettigheter/nettverkskall? Begrunnelse:
- Endret profilformat? Migreringsplan og test:

## Tester
- [ ] Akseptansekriterier gjennomgått
- [ ] Tester kjørt og resultat dokumentert
- [ ] Ingen personlige lyd-/profilfiler i commit
